# instattendance

A  Flutter project to automate the process of taking students attendance and maintain these attendance.
It can prevents the repetitive tasks done by faculty to maintain the attendance like generating report ,calculating
attendacne and many more.

