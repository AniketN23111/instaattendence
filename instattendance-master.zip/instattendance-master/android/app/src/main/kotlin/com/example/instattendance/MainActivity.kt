package com.example.instattendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
