class GsheetConstants {
  static String sheetUrl =
      "https://docs.google.com/spreadsheets/d/1rAxIE-wvA5BakT2-8XvedjF3LpOv5FOQTRXN7nBb0oU/edit?usp=sharing";
}
