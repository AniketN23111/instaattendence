import 'package:flutter/material.dart';

appbarView(String title, Icon icon) {
  return AppBar(
    title: Text(title),
  );
}
